<div class="alert">
    <span class="alert-icon">!</span>
    <span class="msg">Warning: This is a alert</span>
    <span class="close-btn">
        <span class="close-btn-icon">X</span>
    </span>
</div>

<!-- javascript -->
<script type="text/JavaScript" src="<?php echo URLROOT; ?>/js/components/notificationAlert/notificationAlert.js"></script>