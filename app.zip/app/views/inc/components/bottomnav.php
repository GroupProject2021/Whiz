<div class="bottomnav">
        <!-- <div class="social">
            <a href="#"><img src="<?php echo URLROOT; ?>/imgs/home/facebook.png" alt=""></a>
            <a href="#"><img src="<?php echo URLROOT; ?>/imgs/home/instragram.png" alt=""></a>
            <a href="#"><img src="<?php echo URLROOT; ?>/imgs/home/linkedin.png" alt=""></a>
            <a href="#"><img src="<?php echo URLROOT; ?>/imgs/home/youtube.jpg" alt=""></a>
        </div> -->

        <ul class="list-inline">
            <li class="list-inline-item"><a href="<?php echo URLROOT; ?>/Pages/index">Home</a></li>
            <li class="list-inline-item"><a href="<?php echo URLROOT; ?>/Pages/services">Services</a></li>
            <li class="list-inline-item"><a href="<?php echo URLROOT; ?>/Pages/about">About</a></li>
            <li class="list-inline-item"><a href="<?php echo URLROOT; ?>/Pages/contactus">Contact Us</a></li>
            <li class="list-inline-item"><a href="<?php echo URLROOT; ?>/Pages/privacy">Privacy Policy</a></li>
        </ul>

        <p class="copyright">Whiz © 2021. All Rights Reserved</p>
</div>