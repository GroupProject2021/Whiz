        <script src="<?php echo URLROOT;?>/js/main.js"></script>
        <!-- for sidebar -->
        <script type="text/JavaScript" src="<?php echo URLROOT; ?>/js/components/sideBarToggle/sideBarToggler.js"></script>

        <script src="<?php echo URLROOT;?>/js/notificationAlert/notificationAlert.js"></script>
    </body>
</html>

<!-- jQuery -->
<script type="text/JavaScript" src="<?php echo URLROOT; ?>/js/externalLibraries/jQuery/jquery-3.6.0.js"></script>