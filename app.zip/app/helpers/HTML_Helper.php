<?php
    function underConstructPage() {
        echo '<div class="under-construction">';
        echo    '<div class="img">';
        echo        '<img src="'.URLROOT.'/imgs/under-construction.png" height="200px" alt="logo">';
        echo    '</div>';
        echo    '<div class="title">Upload custom CV</div>';
        echo    '<div class="text">';
        echo        'THIS PAGE IS CURRENTLY UNDER CONSTRUCTION !';
        echo    '</div>';
        echo '</div>';
    }
?>