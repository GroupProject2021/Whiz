<?php
    class Post {
        private $db;

        public function __construct() {
            $this->db = new Database;
        }

        // try to refactor from other post modles
    }
?>