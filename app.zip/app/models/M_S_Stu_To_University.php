<?php

class M_S_Stu_To_University {
    private $db;

    public function __construct() {
        $this->db = new Database;
    }
}

?>