<?php
    require_once '../app/bootloader.php';

    // Initialize Core library
    $init = new Core;
?>